package com.example.shoppingapp

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class ProductAdapter(private val products: List<Product>, private val context: Context) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val database: FirebaseDatabase = FirebaseDatabase.getInstance()
    private val cartRef: DatabaseReference = database.reference.child("cart")
    private val favouritesRef: DatabaseReference = database.reference.child("favourites")

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = products[position]
        holder.nameTextView.text = product.name
        holder.descriptionTextView.text = product.description
        holder.priceTextView.text = "$${product.price}"
        holder.imageView.setImageResource(product.image)
        holder.addToCartButton.setOnClickListener {
            val quantityText = holder.quantityEditText.text.toString()
            if (quantityText.isNotEmpty()) {
                val quantity = quantityText.toInt()
                addToCart(product, quantity)
            } else {
                Toast.makeText(context, "Please enter a quantity", Toast.LENGTH_SHORT).show()
            }
        }
        holder.addToFavouritesButton.setOnClickListener {
            val intent = Intent(context, AddToFavouritesActivity::class.java).apply {
                putExtra("productName", product.name)
                putExtra("productDescription", product.description)
                putExtra("productPrice", product.price)
                putExtra("productImage", product.image)
            }
            context.startActivity(intent)
        }
    }

    override fun getItemCount() = products.size

    private fun addToCart(product: Product, quantity: Int) {
        val userId = auth.currentUser?.uid ?: return
        val cartItem = CartItem(
            productId = product.name,
            productName = product.name,
            productPrice = product.price,
            quantity = quantity
        )
        cartRef.child(userId).push().setValue(cartItem)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(context, "${product.name} added to cart", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Failed to add ${product.name} to cart", Toast.LENGTH_SHORT).show()
                }
            }
    }

    class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView: TextView = itemView.findViewById(R.id.productNameTextView)
        val descriptionTextView: TextView = itemView.findViewById(R.id.productDescriptionTextView)
        val priceTextView: TextView = itemView.findViewById(R.id.productPriceTextView)
        val imageView: ImageView = itemView.findViewById(R.id.productImageView)
        val quantityEditText: EditText = itemView.findViewById(R.id.productQuantityEditText)
        val addToCartButton: Button = itemView.findViewById(R.id.addToCartButton)
        val addToFavouritesButton: Button = itemView.findViewById(R.id.addToFavouritesButton)
    }
}
