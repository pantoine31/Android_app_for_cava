package com.example.shoppingapp

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class CartActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase
    private lateinit var cartRef: DatabaseReference
    private lateinit var cartItems: MutableList<CartItem>
    private lateinit var cartAdapter: CartAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()
        cartRef = database.reference.child("cart").child(auth.currentUser!!.uid)
        cartItems = mutableListOf()

        val emailTextView: TextView = findViewById(R.id.emailTextView)
        emailTextView.text = "hey, ${auth.currentUser?.email}"

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        cartAdapter = CartAdapter(cartItems, this)
        recyclerView.adapter = cartAdapter

        fetchCartItems()

        val totalPriceTextView: TextView = findViewById(R.id.totalPriceTextView)
        cartAdapter.setTotalPriceTextView(totalPriceTextView)

        val backButton: Button = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            finish()
        }
    }

    private fun fetchCartItems() {
        cartRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                cartItems.clear()
                for (cartSnapshot in snapshot.children) {
                    val cartItem = cartSnapshot.getValue(CartItem::class.java)
                    cartItem?.let { cartItems.add(it) }
                }
                cartAdapter.notifyDataSetChanged()
                cartAdapter.updateTotalPrice()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@CartActivity, "Failed to load cart items", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
