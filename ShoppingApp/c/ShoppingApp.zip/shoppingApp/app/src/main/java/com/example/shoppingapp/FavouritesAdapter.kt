package com.example.shoppingapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class FavouritesAdapter(private val favourites: List<FavouriteItem>, private val context: Context) : RecyclerView.Adapter<FavouritesAdapter.FavouritesViewHolder>() {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val database: FirebaseDatabase = FirebaseDatabase.getInstance()
    private val favouritesRef: DatabaseReference = database.reference.child("favourites")

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavouritesViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.activity_item_fav, parent, false)
        return FavouritesViewHolder(view)
    }

    override fun onBindViewHolder(holder: FavouritesViewHolder, position: Int) {
        val favourite = favourites[position]
        holder.nameTextView.text = favourite.productName
        holder.descriptionTextView.text = favourite.description
        holder.priceTextView.text = "$${favourite.productPrice}"
        holder.imageView.setImageResource(favourite.image)
        holder.removeFavButton.setOnClickListener {
            removeFromFavourites(favourite)
        }
    }

    override fun getItemCount() = favourites.size

    private fun removeFromFavourites(favourite: FavouriteItem) {
        val userId = auth.currentUser?.uid ?: return
        favouritesRef.child(userId).orderByChild("productId").equalTo(favourite.productId).addListenerForSingleValueEvent(object :
            ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for (favSnapshot in snapshot.children) {
                    favSnapshot.ref.removeValue().addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            Toast.makeText(context, "${favourite.productName} removed from favourites", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Failed to remove ${favourite.productName} from favourites", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(context, "Failed to remove ${favourite.productName} from favourites", Toast.LENGTH_SHORT).show()
            }
        })
    }

    class FavouritesViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView: TextView = itemView.findViewById(R.id.favItemNameTextView)
        val descriptionTextView: TextView = itemView.findViewById(R.id.favItemDescriptionTextView)
        val priceTextView: TextView = itemView.findViewById(R.id.favItemPriceTextView)
        val imageView: ImageView = itemView.findViewById(R.id.favItemImageView)
        val removeFavButton: Button = itemView.findViewById(R.id.removeFavButton)
    }
}
