package com.example.shoppingapp

data class CartItem(
    val productId: String = "",
    val productName: String = "",
    val productPrice: Double = 0.0,
    var quantity: Int = 0
)
