package com.example.shoppingapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button

class StartingPageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_starting_page)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // koumpi about us
        val aboutUsBtn: Button = findViewById(R.id.aboutUsBtn)
        aboutUsBtn.setOnClickListener {
            val intent = Intent(this, AboutUsActivity::class.java)
            startActivity(intent)
        }

        //koumpi contact
        val contactBtn: Button = findViewById(R.id.contactBtn)
        contactBtn.setOnClickListener {
            val intent = Intent(this, ContactActivity::class.java)
            startActivity(intent)
        }

        // koumpi gia epeksergasia profil
        val pfpButton: Button = findViewById(R.id.pfpBtn)
        pfpButton.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }

        // koumpi gia emfanisi products
        val productsButton: Button = findViewById(R.id.productsBtn)
        productsButton.setOnClickListener {
            val intent = Intent(this, ProductsActivity::class.java)
            startActivity(intent)
        }

        //koumpi gia to kalathi
        val cartButton: Button = findViewById(R.id.cartBtn)
        cartButton.setOnClickListener {
            val intent = Intent(this, CartActivity::class.java)
            startActivity(intent)
        }

        //koumpi gia agapimena
        val favButton: Button = findViewById(R.id.favBtn)
        favButton.setOnClickListener {
            val intent = Intent(this, ItemFavActivity::class.java)
            startActivity(intent)
        }

    }
}
