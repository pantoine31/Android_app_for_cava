//package com.example.shoppingapp
//
//class itemFavActivity {
//
//
//}

package com.example.shoppingapp

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class ItemFavActivity : AppCompatActivity() {

    private lateinit var favouritesRecyclerView: RecyclerView
    private lateinit var adapter: FavouritesAdapter
    private val favourites = mutableListOf<FavouriteItem>()

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val database: FirebaseDatabase = FirebaseDatabase.getInstance()
    private val favouritesRef: DatabaseReference = database.reference.child("favourites")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_item_fav)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Setup RecyclerView
        favouritesRecyclerView = findViewById(R.id.favouritesRecyclerView)
        favouritesRecyclerView.layoutManager = LinearLayoutManager(this)
        adapter = FavouritesAdapter(favourites, this)
        favouritesRecyclerView.adapter = adapter

        // Load Favourites from Firebase
        loadFavourites()
    }

    private fun loadFavourites() {
        val userId = auth.currentUser?.uid
        if (userId == null) {
            Toast.makeText(this, "User not signed in", Toast.LENGTH_SHORT).show()
            return
        }

        favouritesRef.child(userId).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                favourites.clear()
                for (favSnapshot in snapshot.children) {
                    val favourite = favSnapshot.getValue(FavouriteItem::class.java)
                    favourite?.let { favourites.add(it) }
                }
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@ItemFavActivity, "Failed to load favourites", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
