package com.example.shoppingapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class CartAdapter(private val cartItems: MutableList<CartItem>, private val context: Context) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    private val database: FirebaseDatabase = FirebaseDatabase.getInstance()
    private lateinit var totalPriceTextView: TextView

    fun setTotalPriceTextView(textView: TextView) {
        totalPriceTextView = textView
        updateTotalPrice()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_cart, parent, false)
        return CartViewHolder(view)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val cartItem = cartItems[position]
        holder.nameTextView.text = cartItem.productName
        holder.priceTextView.text = "$${cartItem.productPrice}"
        holder.quantityEditText.setText(cartItem.quantity.toString())
        holder.imageView.setImageResource(context.resources.getIdentifier(cartItem.productId, "drawable", context.packageName))

        holder.updateButton.setOnClickListener {
            val newQuantity = holder.quantityEditText.text.toString().toInt()
            updateCartItemQuantity(cartItem, newQuantity)
        }
    }

    override fun getItemCount() = cartItems.size

    private fun updateCartItemQuantity(cartItem: CartItem, newQuantity: Int) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val cartRef = database.reference.child("cart").child(userId)
        cartRef.orderByChild("productId").equalTo(cartItem.productId)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    for (cartSnapshot in snapshot.children) {
                        cartSnapshot.ref.child("quantity").setValue(newQuantity)
                        cartItem.quantity = newQuantity
                        updateTotalPrice()
                        notifyDataSetChanged()
                        Toast.makeText(context, "${cartItem.productName} quantity updated", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(context, "Failed to update quantity", Toast.LENGTH_SHORT).show()
                }
            })
    }

    fun updateTotalPrice() {
        val totalPrice = cartItems.sumOf { it.productPrice * it.quantity }
        totalPriceTextView.text = "Total: $%.2f".format(totalPrice)
    }

    class CartViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView: TextView = itemView.findViewById(R.id.cartItemNameTextView)
        val priceTextView: TextView = itemView.findViewById(R.id.cartItemPriceTextView)
        val quantityEditText: EditText = itemView.findViewById(R.id.cartItemQuantityEditText)
        val updateButton: Button = itemView.findViewById(R.id.updateCartItemButton)
        val imageView: ImageView = itemView.findViewById(R.id.cartItemImageView)
    }
}
