package com.example.shoppingapp

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class AddToFavouritesActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase
    private lateinit var favouritesRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_to_favourites)

        // Initialize Firebase
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()
        favouritesRef = FirebaseDatabase.getInstance().getReference("favourites")

        // Bind views
        val productNameTextView: TextView = findViewById(R.id.productNameTextView)
        val productDescriptionTextView: TextView = findViewById(R.id.productDescriptionTextView)
        val productPriceTextView: TextView = findViewById(R.id.productPriceTextView)
        val productImageView: ImageView = findViewById(R.id.productImageView)
        val addToFavouritesButton: Button = findViewById(R.id.addToFavouritesButton)
        val backButton: Button = findViewById(R.id.backButton)

        // Retrieve product details from intent
        val productName = intent.getStringExtra("productName") ?: ""
        val productDescription = intent.getStringExtra("productDescription") ?: ""
        val productPrice = intent.getDoubleExtra("productPrice", 0.0)
        val productImage = intent.getIntExtra("productImage", 0)

        // Set product details to views
        productNameTextView.text = productName
        productDescriptionTextView.text = productDescription
        productPriceTextView.text = "$$productPrice"
        productImageView.setImageResource(productImage)

        // Set click listeners
        addToFavouritesButton.setOnClickListener {
            addToFavourites(productName, productDescription, productPrice, productImage)
        }

        backButton.setOnClickListener {
            finish()
        }
    }

    private fun addToFavourites(name: String, description: String, price: Double, image: Int) {
        val user = auth.currentUser
        if (user == null) {
            Toast.makeText(this, "User not authenticated", Toast.LENGTH_SHORT).show()
            return
        }

        val contactId = favouritesRef.push().key
        if (contactId == null) {
            Log.e("AddToFavourites", "Failed to get a unique key for favourites.")
            Toast.makeText(this, "Failed to add $name to favourites", Toast.LENGTH_SHORT).show()
            return
        }

        val favouriteItem = FavouriteItem(
            productId = contactId,
            productName = name,
            productPrice = price,
            description = description,
            image = image
        )

        // Log User ID and Contact ID to ensure they contain expected values
        Log.d("AddToFavourites", "User ID: ${user.uid}, Contact ID: $contactId")

        // Proceed with adding to favourites
        Log.d("AddToFavourites", "Adding to favourites...")

        favouritesRef.child(user.uid).child(contactId).setValue(favouriteItem)
            .addOnSuccessListener {
                Log.d("AddToFavourites", "Successfully added.")
                Toast.makeText(this, "$name added to favourites", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { exception ->
                Log.e("AddToFavourites", "Failed to add: ${exception.message}")
                Toast.makeText(this, "Failed to add $name to favourites: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }
}

data class FavouriteItem(
    val productId: String = "",
    val productName: String = "",
    val productPrice: Double = 0.0,
    val description: String = "",
    val image: Int = 0
)